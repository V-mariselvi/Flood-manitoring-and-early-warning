# Flood-Monitoring-System
This project is a real-time flood Monitoring system

1.Fetch real-time water level data.

2.Support specific data queries on water level monitoring stations.

3.Analyse monitoring station data in order to assess the flood risk, and issue flood warnings for the people.


